package negocio;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
	
	@RunWith(Suite.class)
	@SuiteClasses({GerenciadoraClientesTest.class, GerenciadoraContasTest.class})
	public class TodosOsTestes {
		
	}